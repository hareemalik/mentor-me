package com.example.mentor

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.PhoneAuthProvider

class MainActivity7 : AppCompatActivity() {

    private lateinit var otpEditText: EditText
    private var verificationId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main7)
        enableEdgeToEdge()

        otpEditText = findViewById(R.id.otp_edit_text)
        val verifyOtpButton: Button = findViewById(R.id.verify_otp_button)

        // Extract verificationId received from MainActivity5
        verificationId = intent.getStringExtra("verificationId")

        verifyOtpButton.setOnClickListener {
            val otpCode = otpEditText.text.toString()
            verifyOtp(otpCode)
        }
    }

    private fun verifyOtp(otpCode: String) {
        val credential = PhoneAuthProvider.getCredential(verificationId!!, otpCode)
        // Sign in with the credential
        // You can implement logic here to handle successful verification and sign in
    }
}
