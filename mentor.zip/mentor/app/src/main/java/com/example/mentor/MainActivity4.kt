package com.example.mentor

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.content.Intent  // Add this import statement
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.firestore.auth.User
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import java.util.*


class MainActivity4 : AppCompatActivity() {

    private lateinit var storage: FirebaseStorage
    private var profilePictureUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)

        storage = FirebaseStorage.getInstance()

        findViewById<Button>(R.id.Button).setOnClickListener {
            openGalleryForImage()
        }

        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun openGalleryForImage() {
        galleryLauncher.launch("image/*")
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            profilePictureUri = uri
            uploadProfilePicture()
        }
    }

    @SuppressLint("RestrictedApi")
    private fun uploadProfilePicture() {
        // Get the current user ID
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        // Check if profile picture Uri is not null
        profilePictureUri?.let { uri ->
            val storageRef = storage.reference
            val picRef = storageRef.child("profile_pictures/${UUID.randomUUID()}")

            val uploadTask = picRef.putFile(uri)
            uploadTask.addOnFailureListener { exception ->
                Toast.makeText(this, "Failed to upload profile picture: ${exception.message}", Toast.LENGTH_SHORT).show()
            }.addOnSuccessListener {

                // Profile picture uploaded successfully, get the download URL
                picRef.downloadUrl.addOnSuccessListener { url ->
                    // Save user data to the database
                    val user = User(userId, "", url.toString())
                    Firebase.database.reference.child("users").child(userId).setValue(user)
                        .addOnCompleteListener { dbTask ->
                            if (dbTask.isSuccessful) {
                                // Profile saved successfully, navigate to the next activity
                                startActivity(Intent(this, UserListActivity::class.java))
                                finish()
                            } else {
                                // Handle error while saving profile to database
                                Toast.makeText(this, "Failed to save profile: ${dbTask.exception?.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                }.addOnFailureListener { exception ->
                    // Handle error while getting download URL
                    Toast.makeText(this, "Failed to get download URL: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
            }
        } ?: run {
            // Handle case where profilePictureUri is null
            Toast.makeText(this, "Profile picture is null", Toast.LENGTH_SHORT).show()
        }
    }

    data class User(val id: String, val name: String, val profilePicture: String) {
        constructor() : this("", "", "")
    }
}


class UserListActivity : AppCompatActivity() {

    private lateinit var databaseRef: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_list)

        // Initialize Firebase Database reference
        databaseRef = FirebaseDatabase.getInstance().reference.child("users")

        // Retrieve list of users from Firebase Realtime Database
        retrieveUsers()
    }

    private fun retrieveUsers() {
        // Read data from Firebase Realtime Database
        databaseRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val userList = mutableListOf<User>()
                // Iterate through the dataSnapshot to retrieve user data
                for (userSnapshot in snapshot.children) {
                    val user = userSnapshot.getValue(User::class.java)
                    user?.let {
                        userList.add(it)
                    }
                }
                // Now you have the list of users, you can display them in your UI
                // For example, you can populate a RecyclerView with this userList
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error when reading data from the database
            }
        })
    }
}
